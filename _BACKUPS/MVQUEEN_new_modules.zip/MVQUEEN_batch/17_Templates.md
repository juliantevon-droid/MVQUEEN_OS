# 📋 MVQUEEN — Templates Library

---

## Purpose

The Templates Library is MVQUEEN's speed layer — pre-built, brand-calibrated frameworks that allow any content, campaign, or operational task to start from quality instead of starting from scratch.

A template is not a shortcut that lowers the bar.
It is a foundation that raises the floor.

Every template in this library has been designed to feel like MVQUEEN before a single word of original content is added.

---

## Template Philosophy

Templates exist to solve three problems:
1. **Speed** — You should not spend time rebuilding structure that already works
2. **Consistency** — Every piece of content should start from the same brand foundation
3. **Quality floor** — Even fast, functional outputs should meet MVQUEEN's standard

Templates are not the output. They are the beginning of the output.
Fill them in, make them specific, add your intelligence — then they become MVQUEEN.

---

## Template Index

| Category | Templates |
|----------|-----------|
| Product Copy | Product Description, Short Copy, Bullet Points, Product Launch Brief |
| Email Marketing | Welcome Series, Promotional Campaign, Post-Purchase, Winback, VIP |
| Social Media | Instagram Caption, TikTok Script, Pinterest Description, Story Sequence |
| Blog & Content | Blog Article, SEO Content Brief, Evergreen Guide, Trend Post |
| Campaign | Campaign Brief, Launch Brief, Giveaway Brief |
| SEO | Meta Title, Meta Description, Collection Page, FAQ Schema |
| SOP | Standard SOP Format, Quick SOP Format |
| Prompt | Agent System Prompt, Task Prompt, Chain Prompt |

---

## PRODUCT COPY TEMPLATES

---

### Template: Full Product Description

```
[PRODUCT NAME]
[Short tagline — 5-8 words, evocative]

---

[SHORT DESCRIPTION — 2 sentences]
Sentence 1: The sensory or emotional experience this product creates.
Sentence 2: The woman it was made for, or the moment it was designed for.

---

[LONG DESCRIPTION — 4 paragraphs]

Paragraph 1 — ATMOSPHERE
Set the scene. Describe the feeling before the product.
What moment does this product belong to?
What does she feel before she reaches for it?

Paragraph 2 — TRANSFORMATION
What changes when she uses this?
How does she feel different, look different, move differently?
Name the shift — not the ingredients.

Paragraph 3 — PRODUCT TRUTH
Now describe what it actually is and does.
Be specific. Be sensory. Lead with the most compelling attribute.
This is where features become experiences.

Paragraph 4 — INVITATION
One or two sentences. Soft close.
Not pressure. Not urgency. An invitation.
"Made for the woman who..." or "This is for her."

---

[BULLET POINTS — 5 benefit statements]
Format each as: [Experience or identity statement] — [what causes it]
Example: "Skin that glows before you're even dressed — a luminous serum that works while you sleep"

• [Benefit 1]
• [Benefit 2]
• [Benefit 3]
• [Benefit 4]
• [Benefit 5]

---

SEO TITLE: [50-60 characters | primary keyword + brand modifier]
SEO META: [150-160 characters | aspirational + keyword + emotional hook]
```

---

### Template: Short Product Copy (for ads and social)

```
[PRODUCT NAME]

[Opening line — the feeling, not the product]
[Second line — what she gets or who it's for]
[Third line — the specific detail that makes it real]
[CTA — soft, identity-based]

Examples of CTAs:
"She deserves this. →"
"Made for your kind of morning."
"Add to your ritual."
"Discover [product name]."
```

---

## EMAIL MARKETING TEMPLATES

---

### Template: Welcome Email (Email 1 of Welcome Series)

```
SUBJECT LINE OPTIONS:
A. [Identity-based] — e.g., "You belong here, [name]"
B. [Curiosity-based] — e.g., "Something is different about this place"
C. [Welcome-based] — e.g., "Welcome to MVQUEEN, queen."

PREVIEW TEXT: [Complements the subject — adds intrigue or warmth]

---

BODY:

[Opening — 1-2 sentences]
Warm, personal, not corporate. She made a decision. Acknowledge it.

[What MVQUEEN is — 2-3 sentences]
Not a brand description. An emotional world description.
This is where she finds out what she just entered.

[What she can expect — brief, warm list or short paragraph]
Make her feel like she's been invited into something intentional.

[First invitation — product, content, or experience]
Give her something to do. One action. Clear, not overwhelming.

[Closing — 1-2 sentences]
Warm. Human. Signed off with brand energy.

SIGNATURE: MVQUEEN
CTA BUTTON: [e.g., "Explore the Collection" / "Start with this →"]
```

---

### Template: Promotional Campaign Email

```
SUBJECT LINE: [3 variations]
A. [Aspiration / Identity angle]
B. [Curiosity / Intrigue angle]
C. [Direct / Offer angle]

PREVIEW TEXT: [Supports subject, adds information or warmth]

---

HEADER: [Campaign visual]

OPENING LINE: [Atmospheric. Sets the emotional scene.]

BODY:
[The offer — framed as an invitation, not a hard sell]
[Why this / why now — the story behind the campaign or season]
[Product spotlight — 1-3 products with emotional framing]
[Social proof — if available, one line review or sentiment]

CTA: [Primary action button]
TEXT: [e.g., "Shop the Collection" / "Discover [Campaign Name]"]

FOOTER: [Secondary message if needed — e.g., "Last chance" or "New arrivals"]
```

---

### Template: Post-Purchase Email

```
SUBJECT: [Celebratory but not generic — acknowledge the specific choice]
Examples: "Your order is on its way, queen." / "[Product name] is yours now."

PREVIEW: [Add warmth or excitement — what she's about to experience]

---

BODY:

[Opening — celebrate the choice, not the transaction]
She didn't just buy something. She made a decision.
Honor it.

[What's coming — set the expectation beautifully]
Describe the experience of receiving it, not just the logistics.

[Order details — clean, minimal]
Order #, expected delivery, tracking link

[What's next — one gentle engagement]
Content recommendation / community invite / related product (soft)

[Close — warm, brand-consistent]
```

---

### Template: Winback Email

```
SUBJECT: [Soft, personal — not "We miss you" (cliché)]
Examples: "Something new caught our eye for you" / "You were made for this one"

---

BODY:

[Opening — acknowledge the gap without guilt-tripping]
No manipulation. No pressure. Just warmth and a reason to return.

[What's new — 1-2 specific products or updates]
Give her a real reason. Not a discount. A discovery.

[Optional offer — if using]
Frame as a gift, not a desperate discount.

[CTA — one clear action]
Low pressure. Inviting. Her choice.

[Close — leave the door open]
She knows she can come back. Make her feel that.
```

---

## SOCIAL MEDIA TEMPLATES

---

### Template: Instagram Caption (Product Post)

```
[Opening line — the feeling or the scene. No "Introducing." No "We're excited."]
[Second line — more specific. The sensory detail. The identity connection.]
[Third line — the product name and what it is. Natural, not promotional.]
[Optional fourth line — social proof, invitation, or emotional closer]

.
.
.

[Hashtag block — 5-10 relevant, non-spammy]
```

---

### Template: TikTok Script

```
HOOK (0-3 seconds): [Visual + audio hook — why would she stop scrolling?]

SETUP (3-8 seconds): [The relatable moment or emotional context]

CONTENT (8-25 seconds): [The product, ritual, or story — shown, not just told]

PAYOFF (25-30 seconds): [The transformation or emotional resolution]

CTA (final frame): [One action — soft, natural, brand-consistent]

CAPTION: [Short. Searchable. Emotional opener + 2-3 hashtags]
```

---

### Template: Pinterest Pin Description

```
[Primary keyword phrase — natural, not forced]
[Aspirational sentence — describe the feeling or lifestyle]
[Product or content description — what it is and what it does]
[Identity statement — who this is for]
[Optional CTA — "Find yours at MVQUEEN.com"]
[Hashtags: 3-5 searchable terms]
```

---

## BLOG & CONTENT TEMPLATES

---

### Template: Blog Article

```
TITLE: [Primary keyword + emotional hook | 50-65 characters]
SUBTITLE: [Supporting statement or reader promise]

META TITLE: [55-60 characters | keyword-led]
META DESCRIPTION: [150-160 characters | aspirational + specific + clickable]

---

INTRODUCTION (150-200 words):
[Open with the woman, not the topic]
[Name the feeling or situation she's in]
[Promise what she'll get from reading this]
[One line transition into the content]

---

BODY SECTIONS:
[H2: Section title — keyword-supported where natural]
[Content: 150-300 words per section]
[Visual: Image or break after every 2-3 sections]

RECOMMENDED STRUCTURE:
1. The context (why this matters to her)
2. The insight or knowledge (the core value)
3. The application (how she uses this)
4. The deeper meaning (identity / emotional connection)
5. The invitation (to shop, explore, or return)

---

CONCLUSION (100-150 words):
[Circle back to the emotional opening]
[Affirm her for reading / being the kind of woman who cares about this]
[Soft CTA — natural, not forced]

---

INTERNAL LINKS: [2-4 links to relevant products or other articles]
CTA: [Link to relevant collection or product]
```

---

## CAMPAIGN TEMPLATES

---

### Template: Campaign Brief

```
CAMPAIGN NAME: [Name]
CAMPAIGN THEME: [One sentence — what is this about?]
EMOTIONAL DIRECTION: [What should she feel from this campaign?]
PRODUCTS FEATURED: [List]
TARGET PERSONA: [Who this is for primarily]

---

CHANNEL PLAN:
Email: [Subject line approach + sequence count]
Instagram: [Number of posts + content mix]
TikTok: [Number of videos + style]
Paid: [Ad types + copy direction]

---

CREATIVE DIRECTION:
Visual: [Color, mood, aesthetic reference]
Copy tone: [Which voice register — softer / bolder / more editorial?]
Key message: [One line that drives everything]

---

TIMELINE:
Build: [Start date]
Launch: [Live date]
Duration: [How long it runs]
Wrap: [End date + analysis date]

---

GOALS:
Primary: [Main KPI]
Secondary: [Supporting metric]
```

---

## SEO TEMPLATES

---

### Template: Meta Title & Description

```
PRODUCT PAGE META TITLE:
[Primary keyword] | [Brand modifier] | MVQUEEN
[Keep under 60 characters]

PRODUCT PAGE META DESCRIPTION:
[Aspiration or identity hook] [product truth] [soft CTA]
[Keep under 160 characters]

BLOG META TITLE:
[Primary keyword phrase] — [Reader promise] | MVQUEEN
[Keep under 60 characters]

BLOG META DESCRIPTION:
[Open with the woman or the feeling] [what she learns] [why MVQUEEN]
[Keep under 160 characters]
```

---

## PROMPT TEMPLATES

---

### Template: Agent System Prompt

```
You are [AGENT NAME] for MVQUEEN — [one-sentence role description].

BRAND IDENTITY:
MVQUEEN is a luxury feminine ecommerce brand built to emotionally elevate modern feminine life.
Voice: warm, feminine, confident, intentional. Never robotic, generic, or emotionally flat.

YOUR ROLE:
[2-3 sentences defining what this agent does]

YOUR SCOPE:
- [Task 1]
- [Task 2]
- [Task 3]

WHAT YOU NEVER DO:
- [Forbidden behavior 1]
- [Forbidden behavior 2]
- [Forbidden behavior 3]

QUALITY STANDARD:
Every output must feel like MVQUEEN — not like AI-generated content.
If it doesn't sound like it belongs in the Brand Bible, revise it.

OUTPUT FORMAT:
[Specify format — length, structure, tone register]
```

---

## Template Usage Rules

1. **Always personalize** — a template filled in verbatim is a template, not content
2. **Read it out loud** — if it sounds robotic or generic, rewrite it
3. **Check the voice** — does this sound like MVQUEEN or does it sound like a brand email?
4. **One CTA** — never more than one primary call to action per piece
5. **Lead with feeling** — the first line should never start with the product or the brand name

---

*MVQUEEN Templates Library — v1.0*
*Start from quality. Land on MVQUEEN.*
