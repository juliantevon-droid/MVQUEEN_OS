# 🧴 MVQUEEN — Product Description Voice

---

## What a Product Description Actually Does

A product description in MVQUEEN is not a spec sheet.
It is the moment a woman decides whether this product belongs in her life.

She is not reading for information. She is reading to feel something.
If the description doesn't create desire in the first two lines, it has failed —
regardless of how accurate the rest of it is.

MVQUEEN product descriptions make her feel the product before she owns it.

---

## The Product Description Standard

Every MVQUEEN product description must:
- Open with a feeling, not a feature
- Name the transformation, not just the ingredients
- Sound specific enough to be credible
- Sound beautiful enough to be desirable
- End with an invitation, not a sales pitch

---

## Description Architecture

### Short Description (2-3 sentences — for product tiles and previews)
```
Sentence 1: The emotional atmosphere or sensory experience.
Sentence 2: What it does — in feeling language.
Sentence 3 (optional): Who it was made for, or the ritual it belongs to.
```

**Example — Body Oil:**
```
A ritual in a bottle. Warm, golden, and weightless — the kind of oil that 
makes her skin feel like it's been taken care of even before she gets dressed.
For the morning she claims as her own.
```

---

### Long Description (4-6 paragraphs — for full product pages)

**Paragraph 1 — The Atmosphere**
Set the scene before the product appears.
Where is she? What moment does this belong to?
What is she feeling or reaching for?

**Paragraph 2 — The Transformation**
What changes when she uses this?
Not the ingredients — the feeling. The shift. The result that matters to her.

**Paragraph 3 — The Product Truth**
Now get specific. What is this product, actually?
Key ingredients, texture, finish, scent, application — in sensory, honest language.

**Paragraph 4 — The Identity Anchor**
Connect it to who she is or who she is becoming.
This is the line that makes her feel like it was made specifically for her.

**Paragraph 5 (optional) — The Ritual**
How does she use it? Make the application feel like a ritual, not an instruction.

**Closing line — The Invitation**
Soft. Confident. Not a command.

---

## Product Description Examples

### Body Butter
**Short:**
```
Rich without weight. The body butter she reaches for before the rest of the world begins.
A deep moisture formula that sinks in fast and leaves skin feeling wrapped in warmth.
Made for her quiet morning.
```

**Long:**
```
Some mornings need a slower start.

This is for those mornings — when she takes five minutes before the day 
claims her. When she smooths something beautiful onto her skin and 
remembers that taking care of herself is not an indulgence. It is the ritual 
that makes everything else possible.

MVQUEEN Velvet Body Butter absorbs completely within minutes, leaving no 
greasy residue — just soft, visibly nourished skin that holds moisture for 
hours. The scent is warm and subtle. The texture is rich without feeling heavy.

It was formulated for the woman who wants her skincare to feel intentional — 
not like another task on her morning checklist.

Apply generously after showering while skin is still slightly warm. Work it in 
slowly. She's worth the extra sixty seconds.

Her ritual, elevated.
```

---

### Lip Color
**Short:**
```
The one she reaches for on no-makeup days. A soft, buildable lip color that 
feels like nothing and looks like everything. Made for her kind of effortless.
```

---

### Facial Serum
**Short:**
```
Two drops that change what her skin does overnight. A lightweight serum 
formulated for women who want results without a ten-step routine. Her skin 
wakes up differently when she uses this — she'll notice by morning three.
```

---

## Bullet Point Formula

Bullets answer: **what does she get** — in her language.

**Formula:**
```
[The experience or result] — [what creates it, briefly]
```

**Examples:**
- Skin that feels hydrated for 12+ hours — a hyaluronic complex that pulls moisture deep
- No white cast, no shine — a formula that disappears on contact
- The glow she gets asked about — light-reflecting particles that work with her skin tone
- Effortless application — a cushion tip designed for precise, buildable coverage
- Scent that lasts past her morning — a fragrance base that bonds with skin warmth

**Bullets that break the MVQUEEN standard:**
- ❌ "Contains hyaluronic acid" — says nothing about the experience
- ❌ "Moisturizes skin" — too generic to mean anything
- ❌ "Dermatologist tested" — credibility claim without feeling
- ❌ "Suitable for all skin types" — fine as a secondary bullet, never a lead

---

## Voice Don'ts Specific to Product Copy

- Never open with the product name
- Never open with "Introducing"
- Never use "packed with" (e.g., "packed with nutrients") — clinical and cheap
- Never list ingredients without translating them into experience
- Never close with "Shop now" — close with an invitation or the product name alone
- Never describe the packaging before the feeling

---

*06_Tone_And_Voice / Product_Description_Voice.md*
*She reads the description to feel it. Write accordingly.*
