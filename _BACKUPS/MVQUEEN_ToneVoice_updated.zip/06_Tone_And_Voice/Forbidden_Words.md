# 🚫 MVQUEEN — Forbidden Words & Phrases

---

## Why This Exists

Words carry emotional weight.
The wrong word in a MVQUEEN piece of copy doesn't just read poorly —
it breaks the atmosphere the entire brand is built on.

This list is not about being restrictive.
It is about being intentional.

Every word on this list has a better alternative.
Use the alternative.

---

## Category 1 — Generic Quality Claims

These words say nothing specific. Every brand uses them. They signal low effort.

| Forbidden | Why | Use Instead |
|-----------|-----|-------------|
| High-quality | Describes nothing | Name the specific quality: "hand-poured," "silk-threaded," "cold-pressed" |
| Premium | Overused to meaninglessness | "crafted," "considered," "refined" |
| Luxurious | Tell don't say | Describe what makes it feel luxurious |
| Amazing | Empty superlative | Be specific about what's remarkable |
| Stunning | Overused | Name what she actually sees or feels |
| Incredible | Vague enthusiasm | Describe what's actually notable |
| Best-in-class | Corporate cliché | Say what makes it the best — or don't claim it |
| World-class | Unverifiable | Remove entirely |
| Top-tier | Generic | Be specific |

---

## Category 2 — Urgency & Pressure Language

MVQUEEN never pressures. Urgency is the energy of desperation, not luxury.

| Forbidden | Why | Use Instead |
|-----------|-----|-------------|
| Act now | Aggressive | "Available while the collection lasts" |
| Don't miss out | FOMO manipulation | "She won't want to miss this" (rare use only) |
| Limited time only | Cheap pressure | "Available through [specific date]" |
| Hurry | Panic energy | Remove entirely |
| Last chance | Desperate | "Final days of the collection" |
| Buy now | Transactional | "Add to your ritual" / "Make it yours" |
| Only X left | Anxiety-inducing | "Nearly gone" (soft, rare) |
| Flash sale | Discount-brand energy | "A moment to shop the collection" |

---

## Category 3 — Hollow Positivity

These phrases are performative — they gesture at warmth without delivering it.

| Forbidden | Why | Use Instead |
|-----------|-----|-------------|
| We're excited to announce | Corporate opener | Open with the thing itself |
| We're thrilled | Same | Lead with what matters |
| Introducing... | Lazy opener | Open with the feeling or the story |
| Game-changing | Tech bro energy | Describe what actually changes |
| Revolutionary | Overused | Say what's genuinely different |
| You deserve it | Hollow affirmation | Show her why through the product itself |
| Treat yourself | Cliché | "Made for a morning like this" |
| Spoil yourself | Same | Remove entirely |

---

## Category 4 — Price & Affordability Language

MVQUEEN positions in emotional luxury. Price language undermines that.

| Forbidden | Why | Use Instead |
|-----------|-----|-------------|
| Cheap | Never | Remove entirely |
| Affordable | Budget-brand energy | "Thoughtfully priced" / remove entirely |
| Budget-friendly | Same | Remove |
| Great value | Discount positioning | Remove |
| Price drop | Commodity language | "Now available at [price]" |
| Sale | Use sparingly | "The collection" / "A curated selection" |

---

## Category 5 — Robotic & Corporate Language

MVQUEEN is human. This language removes the human.

| Forbidden | Why | Use Instead |
|-----------|-----|-------------|
| Leverage | Corporate | Use a real word |
| Synergy | Meaningless | Remove |
| Utilize | Formal/stiff | "Use" |
| Optimal | Clinical | "Best" / describe specifically |
| Seamless | Overused in tech | Describe the actual experience |
| Streamlined | Same | Remove or be specific |
| Solutions | B2B language | Name the actual thing |
| Offerings | Cold | "Collection" / "products" |
| Curated selection | Overused | Describe what was actually selected and why |

---

## Category 6 — Overused Beauty Industry Language

These exist in every beauty brand's copy. MVQUEEN needs its own language.

| Forbidden | Why | Use Instead |
|-----------|-----|-------------|
| Glow up | Cliché | "Radiance" / describe the skin |
| Boss babe | Dated energy | Remove entirely |
| Self-care Sunday | Cliché | Name the ritual specifically |
| That girl | Trend-dependent | Remove — will age poorly |
| Glowing skin | Generic | Name the texture, light, finish specifically |
| Confidence boost | Empty | Describe what she feels specifically |
| Feel your best | Vague | Describe what "best" looks like for her |
| Empowered | Overused | Show empowerment through copy, don't label it |
| Slay | Dated | Remove entirely |

---

## The Test

Before publishing any copy, read it and ask:

**Could any other beauty brand have written this?**

If yes — rewrite it until only MVQUEEN could have written it.

---

*06_Tone_And_Voice / Forbidden_Words.md*
*Language is the brand. Protect it.*
