# 📲 MVQUEEN — Social Voice Guide

---

## How MVQUEEN Sounds on Social

Social is where MVQUEEN is most visible and most vulnerable.
It is where the brand either builds real emotional connection — or disappears into noise.

The social voice is a slightly more conversational version of the brand voice.
Still elevated. Still intentional. But with room to breathe, play, and connect.

MVQUEEN on social sounds like her most self-possessed friend —
the one who posts intentionally, captions thoughtfully, and never tries too hard.

---

## Platform-by-Platform Voice

### Instagram
**Energy:** Editorial meets intimate. Beautiful but real.
**Tone:** Warm, aspirational, identity-affirming.
**Caption length:** Medium — 3-6 lines for image posts. Short for reels.
**Hashtags:** 5-10, relevant, non-spammy. After a line break.
**What thrives:** Lifestyle imagery with emotionally resonant captions. Behind-ritual moments. Product stories.

**Voice example:**
```
She didn't rush this morning.
She took her time — and it showed.

The Velvet Morning Set. Now in the collection.
Link in bio 👑

#MVQUEEN #FeminineRitual #SoftLuxury #MorningRitual
```

---

### TikTok
**Energy:** Real, direct, magnetic. Still her — just faster.
**Tone:** Conversational, slightly bolder, hook-first.
**Caption length:** Short. 1-3 lines. The video carries the weight.
**Hashtags:** 3-5 specific ones, not a wall of tags.
**What thrives:** POV content, ritual reveals, "the reason I switched" format, before-and-feel content.

**Voice example:**
```
The reason her skin looks like that every morning 👇

#MVQUEENRitual #GlowRoutine #SkincareTikTok
```

---

### Pinterest
**Energy:** Evergreen, aspirational, search-aware.
**Tone:** Descriptive, sensory, SEO-informed but still poetic.
**Caption length:** 2-4 sentences. Searchable opener.
**What thrives:** Ritual lifestyle imagery, product flatlays, soft aesthetic content.

**Voice example:**
```
Soft glam morning ritual for the woman who moves intentionally.
MVQUEEN Luminous Routine — a glow that starts before she leaves the bathroom.
Discover the full collection at MVQUEEN.com
#SoftGlam #FeminineRitual #GlowRoutine
```

---

## Caption Formulas by Content Type

### Product Caption Formula
```
[Scene — where she is, what she's doing]
[The feeling the product creates or enhances]
[Product name, minimally introduced]
[Soft CTA or identity statement]
[Line break]
[Hashtags]
```

### Lifestyle / Atmosphere Caption Formula
```
[Observation about a feeling or moment she recognizes]
[Expand — give it texture]
[Connect to the brand world — not a product push]
[Open-ended close or subtle invitation]
```

### Launch Caption Formula
```
[Tease the feeling before naming the product]
[Name it — simply, confidently]
[What it does in her language — 1 line]
[CTA — link in bio or swipe]
```

### Community / Connection Caption Formula
```
[Start with her — something she's felt or done]
[Mirror it back — MVQUEEN sees her]
[No CTA — this is connection, not conversion]
```

---

## Hashtag Strategy

**Tier 1 — Brand hashtags (always include at least 1)**
- #MVQUEEN
- #MVQUEENRitual
- #MVQUEENQueen
- #MVQUEENOS (for system content)

**Tier 2 — Community hashtags (mix in)**
- #FeminineRitual
- #SoftLuxury
- #SoftGlam
- #GlowRitual
- #FeminineLiving
- #LuxuryBeauty
- #MorningRitual
- #SkincareCommunity
- #FeminineEnergy

**Tier 3 — Searchable / discovery hashtags (rotate)**
- #GlowRoutine
- #SkincareTikTok
- #BeautyRitual
- #LuxurySkincare
- #FeminineAesthetic
- #MorningRoutine
- #SelfCareRitual
- #WomenWhoBuild

---

## What MVQUEEN Never Does on Social

- Trend-chases without brand alignment (if it doesn't feel like MVQUEEN, it doesn't post)
- Uses slang that will feel dated in 6 months
- Over-posts to fill a calendar — quality over consistency
- Posts product photos with no emotional context
- Responds to negativity publicly with defensiveness
- Uses ALL CAPS in captions
- Posts anything that feels rushed or below standard
- Mimics competitor content even subtly

---

## Comment & Engagement Voice

When MVQUEEN responds in comments:

**Tone:** Warm, personal, never scripted-feeling.

**Examples:**

To a compliment:
- "She knows. 👑 We made this for her."
- "This means everything — truly. 🤍"
- "She sees it. That's the whole point."

To a question about a product:
- "Yes — and it's [specific honest answer]. DM us for anything else, queen."

To a concern or issue:
- "We want to make this right — please DM us directly so we can take care of you. 🤍"

To UGC or tags:
- "She gets it. 👑 [Tag them] — this is what it looks like when she takes her time."

---

*06_Tone_And_Voice / Social_Voice.md*
*Social is where she finds MVQUEEN. Make sure what she finds is worth staying for.*
