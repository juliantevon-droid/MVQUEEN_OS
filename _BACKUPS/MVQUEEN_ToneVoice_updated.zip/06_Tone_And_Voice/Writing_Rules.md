# 📐 MVQUEEN — Writing Rules

---

## The Rules That Protect the Voice

These are not suggestions. They are the structural guardrails that keep every piece of MVQUEEN copy consistent — regardless of who wrote it, which AI generated the draft, or how fast the deadline is.

When in doubt, come back here.

---

## RULE 01 — Lead With Feeling

The first sentence of every MVQUEEN piece should make her feel something.
Not inform her. Not introduce the product. Not start with the brand name.

**Wrong:**
> MVQUEEN's new Velvet Body Butter is now available.

**Right:**
> Some mornings deserve to start slowly — this is for those mornings.

---

## RULE 02 — Never Open With "We"

"We are excited..." / "We are proud to..." / "We believe..."
All of these center the brand instead of the woman.

MVQUEEN copy centers her — always.

**Wrong:**
> We created this collection for the modern woman.

**Right:**
> She's been building her ritual for years. This collection was made to meet her there.

---

## RULE 03 — One Idea Per Paragraph

Each paragraph carries one thought. One feeling. One truth.
When a paragraph tries to carry multiple ideas, it loses all of them.

Paragraph length: 2-4 sentences maximum in most contexts.
Email and product copy: often 1-2 sentences per paragraph.

---

## RULE 04 — Short Sentences Break Long Rhythm

Long, complex sentences build atmosphere.
Short sentences land truth.
Use both. Alternate intentionally.

**Example:**
> She didn't plan for this to become her ritual. She just reached for it one morning — and then kept reaching for it. Now it's the thing she won't share.

---

## RULE 05 — Specificity Over Generality — Always

A specific detail creates a real image in her mind.
A general claim creates nothing.

**General:** "A serum that improves your skin."
**Specific:** "A serum she notices by morning three — less dullness, more of that glow she used to think was just good genes."

If you can't be specific, you don't know the product well enough yet.
Learn it first. Then write.

---

## RULE 06 — Read It Out Loud

If it sounds robotic when spoken, it reads robotic on screen.
If it sounds like a real woman wrote it — it's closer.

Read every piece of MVQUEEN copy out loud before it publishes.
If you stumble, rewrite.

---

## RULE 07 — The "Could Anyone Else Have Written This?" Test

After writing any piece of MVQUEEN copy, ask:
**Could this sentence appear in a competitor's email without changing a word?**

If yes — rewrite it. Make it irreplaceably MVQUEEN.

---

## RULE 08 — No Exclamation Marks in Body Copy

Enthusiasm shows in word choice. Not punctuation.
An exclamation mark in MVQUEEN body copy signals low effort.

Exception: SMS, and even there — maximum one per message, never in a headline.

---

## RULE 09 — Contractions Are Allowed. Preferred, Even.

MVQUEEN is warm and human. "She's" not "she is." "It's" not "it is."
Contractions make copy feel like a real person wrote it.
Use them.

---

## RULE 10 — The Product Is Never the Hero

She is the hero. The product is what she reaches for.

This distinction changes everything.
When the product is the hero: "Our serum will transform your skin."
When she is the hero: "Her skin does something different now. Two drops, every morning. That's her whole secret."

---

## RULE 11 — Never Use "Journey" or "Transform" as Standalone Verbs

"Go on a journey with us." "Transform yourself."
These are the most overused words in beauty and wellness marketing.

If she is transforming — show the transformation in specific language.
If there is a journey — describe where she starts and where she arrives.
Never use the word as a substitute for the actual description.

---

## RULE 12 — Avoid Stacking Adjectives

One precise adjective is stronger than three vague ones.

**Weak:** "A rich, luxurious, deeply nourishing body butter."
**Strong:** "A body butter so rich it changes what her morning skin feels like."

Stack feeling. Not adjectives.

---

## RULE 13 — Every CTA Is Singular

One email. One CTA.
One ad. One CTA.
One caption. One action.

Multiple CTAs fracture her attention and reduce all of them to nothing.
Choose the most important one. Trust it.

---

## RULE 14 — Her Race, Body, and Age Are Never Assumed

MVQUEEN is for women — across skin tones, body types, and stages of life.
Copy never assumes what she looks like.
Imagery handles representation. Copy stays identity-specific, not appearance-specific.

---

## RULE 15 — AI Copy Gets One More Pass

If AI generated the draft — it gets one more human pass before it publishes.
Read it as the woman it was written for.
Does it feel like MVQUEEN?
Does it feel like it was written for her, specifically?
If not — refine until it does.

---

*06_Tone_And_Voice / Writing_Rules.md*
*Rules are not limits. They are the reason MVQUEEN sounds like MVQUEEN.*
