# 🔒 MVQUEEN — Voice Consistency Rules

---

## Why Consistency Matters

A brand voice is only valuable when it is consistent.

One off-brand email, one generic ad, one robotic product description —
and the trust MVQUEEN has built begins to fracture.
The woman who felt seen by the brand voice starts to feel like she imagined it.

Consistency is not rigidity. It is reliability.
She should recognize MVQUEEN's voice the moment she encounters it —
regardless of channel, format, or who wrote it.

---

## The Non-Negotiables (Never Deviate)

These hold across every format, channel, tool, or team member:

1. **She is always the center.** Copy centers the woman, not the brand.
2. **Feeling before feature.** Always lead with emotional context.
3. **No pressure language.** No urgency-based manipulation. Ever.
4. **No hollow affirmations.** "You deserve it" and "treat yourself" are forbidden.
5. **No exclamation marks in body copy.** Enthusiasm lives in words, not punctuation.
6. **One CTA per piece.** Never compete with yourself.
7. **Specificity over generality.** A real detail beats a vague claim every time.
8. **Contractions are standard.** She's, it's, here's — warm and human.

---

## The Consistency Checkpoints

Before any piece of content publishes, run it through these five checks:

**Check 1 — The Identity Check**
Does this sound like MVQUEEN — or could any beauty brand have written it?
If any other brand could claim this copy, rewrite it.

**Check 2 — The Centering Check**
Who is the center of this piece — the brand or the woman?
If the brand is the subject more than she is — rewrite it.

**Check 3 — The Feeling Check**
What does she feel when she reads this?
If the answer is "nothing in particular" — rewrite it.

**Check 4 — The Forbidden Words Check**
Run it against `Forbidden_Words.md`.
Any violations — replace immediately.

**Check 5 — The Read-Aloud Check**
Read it out loud as the woman it was written for.
Does it flow? Does it feel real? Does it sound like a human wrote it?
If not — rewrite it.

---

## Voice Across Different Contexts

The voice adapts in *energy* — not in *identity.*

| Context | Energy Shift | What Stays the Same |
|---------|-------------|---------------------|
| Product page | Evocative, sensory | Feeling-first, specific, centered on her |
| Email | Intimate, personal | Warm, single CTA, never pressured |
| Social | More conversational | Identity-affirming, never generic |
| SMS | Efficient, warm | Short but never cold, never urgent |
| Ad | Bold hook, immediate | Identity-based, one message |
| Blog | Thoughtful, expansive | Her-centered, credible, beautiful |
| Customer service | Warm, direct | Never defensive, never scripted |

The voice is the same woman in different rooms.
Her personality doesn't change. Her register adjusts to the room.

---

## Multi-Person Consistency

When more than one person writes for MVQUEEN:

- Every writer reads this file and `Writing_Rules.md` before their first draft
- Every draft is reviewed against the brand voice before publishing
- AI-generated content receives an additional human pass — always
- No piece publishes without passing the five consistency checkpoints
- When in doubt, the founder has final say on voice

---

## AI Consistency Protocol

When using AI to generate MVQUEEN copy:

1. Always include the brand voice system prompt (from `36_Agent_Systems`)
2. Always include the forbidden words list in the prompt
3. Always include 2-3 example pieces from the Brand Voice Corpus
4. Review every AI output before it enters the workflow
5. Run every AI output through the five consistency checkpoints
6. Edit what needs editing — AI drafts, humans finalize

AI that is properly prompted produces MVQUEEN-adjacent copy.
Human review makes it MVQUEEN.

---

## Voice Drift Warning Signs

Watch for these signals that the voice is drifting:

- Copy starts opening with the brand name or "We"
- Exclamation marks appear in body copy or headlines
- Generic beauty language returns ("glowing skin," "feel your best")
- Urgency phrases appear ("limited time," "act now")
- Paragraphs grow longer and more bloated
- The woman disappears from the center of the copy
- Multiple CTAs start appearing in single pieces
- Products are described by features without emotional context

If any of these appear — pause, return to this file, and recalibrate.

---

*06_Tone_And_Voice / Voice_Consistency_Rules.md*
*The voice is the brand. Protect it like one.*
