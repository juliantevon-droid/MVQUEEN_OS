# 👑 MVQUEEN — CTA Library

---

## CTA Philosophy

A call to action in MVQUEEN copy is never a command.
It is an invitation.

The difference is felt — not just read.
"Buy Now" is a command. "Make it yours" is an invitation.
One creates pressure. The other creates desire.

MVQUEEN CTAs are soft, identity-based, and specific.
They never push. They open a door and let her walk through.

---

## SHOP & PRODUCT CTAs

**Primary (buttons, links)**
- Make it yours →
- Add to your ritual →
- Shop the collection →
- Discover [Product Name] →
- Start here →
- Find yours →
- Bring it home →
- Enter the collection →
- Shop now, queen →
- Begin your ritual →

**Secondary (inline text)**
- Available now in the collection.
- Yours to discover.
- She won't want to miss this one.
- The collection is live — and it won't wait forever.
- Now available. Finally.

---

## EMAIL CTAs

**Subject line closers**
- (she's already obsessed)
- — for her.
- — finally.
- — and it's everything.
- — queen approved.

**Body CTAs**
- See what she's been waiting for →
- Explore the full collection →
- Take a look →
- She deserves this →
- This one's for her →
- Open the collection →
- It's ready when she is →

---

## SOCIAL CTAs

**Instagram**
- Link in bio, queen 👑
- Shop through the link in bio →
- She knows where to find it.
- Tap to explore →
- It's yours if you want it →
- Comment "RITUAL" for the link
- Save this for your next restock ✨

**TikTok**
- Link in bio →
- Comment "QUEEN" for the link
- Follow for more →
- Shop before it's gone →
- This is the one she keeps talking about

**Pinterest**
- Find it at MVQUEEN.com →
- Shop the look →
- Discover the full ritual →

---

## WELCOME & ONBOARDING CTAs

- Start exploring →
- Enter your world →
- Begin here →
- See what's new →
- Welcome home. Start here →
- Discover what she built for you →

---

## RETENTION & LOYALTY CTAs

- Return to your ritual →
- She's been waiting for you →
- Welcome back, queen →
- Your favorites are still here →
- Something new just arrived for her →
- Redeem your rewards →
- You've earned this →

---

## CONTENT & BLOG CTAs

- Read more →
- Continue reading →
- She wrote this for you →
- The full ritual is here →
- Explore more →
- Discover the collection behind this →

---

## CTAs TO NEVER USE

| Never | Why |
|-------|-----|
| Buy Now | Commands. Creates pressure. |
| Click Here | Generic. Tells her nothing. |
| Submit | Cold and corporate. |
| Add to Cart | Transactional, not aspirational. |
| Purchase | Too formal. |
| Grab yours | Too casual for the brand register. |
| Don't miss out | FOMO-driven. Beneath MVQUEEN. |
| Act fast | Panic energy. Never. |
| Limited time | Cheap urgency. Never. |

---

## CTA Formula

When building a new CTA:

1. **Start with what she gets** — not what she does
2. **Make it identity-adjacent** — who does this make her?
3. **Keep it under 5 words** when possible
4. **Add → only when it signals movement** — don't use it decoratively
5. **Test it against the doctrine** — does this feel like MVQUEEN?

---

*06_Tone_And_Voice / CTA_Library.md*
*Every CTA is the last thing she reads before she decides. Make it count.*
