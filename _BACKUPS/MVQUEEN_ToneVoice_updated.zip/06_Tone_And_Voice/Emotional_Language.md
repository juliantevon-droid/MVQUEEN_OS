# 💜 MVQUEEN — Emotional Language Guide

---

## What Emotional Language Is

Emotional language is not flowery writing.
It is precise writing — language that names a specific feeling so accurately
that the woman reading it feels recognized.

The difference between generic copy and MVQUEEN copy is almost always
one thing: emotional specificity.

Generic: "Feel confident and beautiful."
Emotional: "The kind of morning where she catches her reflection and pauses — not to critique, but to recognize herself."

Both are about confidence. Only one lands.

---

## The Emotional Vocabulary of MVQUEEN

These are the emotional territories MVQUEEN operates in.
Every piece of copy should touch at least one of these.

### Quiet Confidence
Words and phrases that evoke this:
- soft power, settled, grounded, unhurried, present
- "she doesn't announce herself — she arrives"
- "the kind of confidence that doesn't need to explain itself"
- "she's not trying to be seen — she just is"

### Feminine Softness
- warmth, tenderness, gentleness, ease, flow
- "soft in all the right ways"
- "the softness she's been protecting"
- "femininity as a choice she makes every morning"

### Ritual and Intentionality
- intentional, deliberate, considered, unhurried, present
- "she moves through her morning with purpose"
- "this is not maintenance — it is devotion"
- "the ritual that makes the rest of the day possible"

### Elevation Without Exclusion
- elevated, refined, luminous, considered
- "luxury that feels like breathing — not performing"
- "she doesn't have to prove she belongs here"
- "beautiful, and entirely within reach"

### Emotional Recognition
- seen, understood, reflected, known
- "she's been looking for something that understood her"
- "the brand that sees her the way she sees herself"
- "she doesn't have to translate herself here"

### Transformation Through Consistency
- restored, returned, arrived, realigned
- "she came back to herself"
- "not a new her — a more present her"
- "the version of her that doesn't feel like it needs maintenance"

---

## Emotional Language by Product Category

### Skincare
Lead emotions: restoration, presence, care, luminosity
Language: "her skin the way it wants to be," "morning light," "what care actually feels like," "the glow underneath"

### Body Care
Lead emotions: warmth, softness, ritual, embodiment
Language: "the body she returns to," "warmth that starts from outside," "the ritual before the world begins"

### Fragrance
Lead emotions: memory, atmosphere, identity, mood
Language: "she remembers this feeling," "the scent that becomes her," "mood as a choice"

### Makeup & Color
Lead emotions: expression, playfulness, power, intention
Language: "the way she showed up today," "she chose this," "a face that's entirely hers"

### Hair Care
Lead emotions: texture, movement, confidence, care
Language: "hair that moves the way she does," "the version of her hair she's always reached for"

---

## Emotional Language Patterns That Work

**The Recognition Pattern:**
Name something she's felt but never heard said exactly this way.
> "The feeling of finally getting a skincare routine right — not perfect, just right — is one of the quiet victories nobody talks about."

**The Permission Pattern:**
Give her permission to want something beautiful for no reason except that it's beautiful.
> "She doesn't need an occasion to take care of herself. Tuesday is enough."

**The Mirror Pattern:**
Describe her back to herself — and make her feel seen by the accuracy.
> "She's not high-maintenance. She's high-intentioned. There's a difference she's been trying to explain for years."

**The Elevation Without Judgment Pattern:**
Lift her up without implying she needs lifting.
> "She's already the woman. The ritual just helps her remember."

**The Specificity Pattern:**
The more specific the detail, the more emotionally real it becomes.
> "The serum she reaches for before she's even fully awake. Eyes half-open. Still warm from sleep. That specific."

---

## What Emotional Language Is Not

- Emotional language is not adjective-stacking
  *Wrong:* "A rich, deeply nourishing, luxuriously soft body butter"
  *Right:* "A body butter she doesn't want to stop applying"

- Emotional language is not hollow affirmation
  *Wrong:* "You deserve to feel beautiful"
  *Right:* "She already is beautiful — this just makes her feel it"

- Emotional language is not manipulation
  Emotional language in MVQUEEN creates genuine resonance.
  It never uses guilt, shame, fear, or insecurity to sell.

- Emotional language is not performance
  It doesn't try to sound poetic. It is honest in a way that happens to be beautiful.

---

*06_Tone_And_Voice / Emotional_Language.md*
*Precision in feeling is what separates MVQUEEN from everything else.*
