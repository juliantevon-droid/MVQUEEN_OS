# 🤝 MVQUEEN — Influencer & Creator Strategy

---

## Influencer Philosophy

MVQUEEN does not work with influencers for reach alone.
It works with creators who genuinely embody the brand's emotional world — women whose audiences trust them because they show up authentically, and whose personal aesthetic aligns with MVQUEEN's without requiring them to perform it.

The wrong creator partnership — even with massive reach — does more damage than no partnership.
MVQUEEN's brand world is specific. It cannot be borrowed by someone who doesn't inhabit it.

---

## Creator Tiers

### Tier 1 — Nano Creators (1K–10K followers)
**Why they matter:** Highest engagement rates, most trusted by their audience, most affordable to activate.
**MVQUEEN use:** Product gifting, authentic UGC generation, community building.
**Conversion power:** Highest per-follower. Her audience listens to her the way they listen to a friend.
**Compensation:** Product gifting. No payment required at this tier.

### Tier 2 — Micro Creators (10K–100K followers)
**Why they matter:** Still highly trusted, niche audiences, consistent aesthetic.
**MVQUEEN use:** Brand introduction, product launches, ritual content.
**Conversion power:** Strong. She has built real relationship with her audience.
**Compensation:** Product + affiliate commission or flat fee ($100–$500 per deliverable).

### Tier 3 — Mid-Tier Creators (100K–500K followers)
**Why they matter:** Meaningful reach with retained authenticity if selected carefully.
**MVQUEEN use:** Launch amplification, seasonal campaigns, brand awareness.
**Conversion power:** Moderate — depends heavily on audience alignment.
**Compensation:** Flat fee ($500–$2,500 per campaign) + product.

### Tier 4 — Macro Creators (500K+)
**Why they matter:** Mass reach, cultural visibility.
**MVQUEEN use:** Brand awareness only — not direct conversion campaigns.
**Consideration:** High cost, lower engagement rates, audience alignment risk.
**Approach:** Only when budget and brand positioning support it. Never as a primary strategy.

---

## Creator Selection Criteria

Before any creator partnership — evaluate against all six:

**1. Emotional alignment**
Does her content feel like MVQUEEN's world? Warm, feminine, intentional, elevated.
Not: loud, trend-chasing, aggressive promotional energy.

**2. Audience alignment**
Is her audience the MVQUEEN woman — or adjacent?
Check: age range, interests, engagement quality (comments vs just likes).

**3. Aesthetic consistency**
Does her visual presentation — photography, color, editing — align with MVQUEEN's warm, soft, luminous palette?
A creator whose aesthetic is dark and moody cannot authentically represent MVQUEEN.

**4. Authentic usage**
Would she plausibly use this product in her real life?
Forced product integration is visible — and damaging to both the creator and the brand.

**5. Content quality**
Is her content well-produced? Thoughtful? Does it create desire?
MVQUEEN's products should be shown in content that honors them.

**6. Brand history**
Has she partnered with brands that conflict with MVQUEEN's positioning or values?
Competing brands in her feed = diluted impact. Conflicting brands = brand association risk.

---

## Partnership Models

### Gifting (No Contract)
Product sent in exchange for authentic content — if she loves it.
No post requirement. No pressure. No scripted language.
**When:** Nano tier, initial relationship building, testing fit before paid partnership.

### Affiliate Partnership
Unique discount code or tracking link. She earns commission on sales she drives.
**Commission rate:** 10–15% on tracked sales.
**When:** Micro and mid-tier creators with proven conversion audience.
**Platform:** Built in Shopify + tracked via affiliate app.

### Paid Collaboration
Flat fee for defined deliverables (number of posts, format, usage rights).
**Deliverable examples:** 1 TikTok + 2 Stories, or 1 Reel + 1 static post.
**Brief:** Provided but not scripted — she speaks in her voice, MVQUEEN-aligned.
**Approval:** MVQUEEN reviews content before posting for brand alignment (not creative control).

### Brand Ambassador
Long-term relationship (3–6 months). Recurring posts, exclusive discount code, early product access.
**For:** Creators who are genuinely MVQUEEN women — not performers of the aesthetic.
**Compensation:** Monthly retainer + product + commission.

---

## Creator Brief Template

When briefing a paid or gifted creator:

```
BRAND:              MVQUEEN — Most Valuable Queen
PRODUCT:            [Product name + key emotional promise]
CAMPAIGN:           [What this is part of]
DELIVERABLES:       [Specific posts, formats, timeline]

WHAT WE LOVE ABOUT YOUR CONTENT:
[Specific reason she was chosen — make it personal and true]

BRAND DIRECTION (not a script):
- MVQUEEN is a feminine luxury brand built on emotional transformation
- The woman who uses our products is intentional, soft, confident
- Voice: warm, not hype. Genuine, not performative
- Show the product in your real ritual — not a staged demo

WHAT TO AVOID:
- Aggressive promotional language ("You NEED this!")
- Discount urgency unless it's part of the campaign
- Generic beauty language ("This changed my skin!")
- Any language from our forbidden words list [attached]

HASHTAGS: #MVQUEEN #MVQUEENRitual + your usual tags
DISCOUNT CODE: [Her unique code] (10% off for her audience)
USAGE RIGHTS: We'd love to repurpose great content — [specific terms]
```

---

## What MVQUEEN Never Does in Creator Partnerships

- Partners with creators whose primary content is drama, controversy, or conflict
- Requires scripted language that sounds like an ad, not a person
- Works with creators who promote brands directly competing with MVQUEEN
- Sends products without a personal note — packaging is brand experience
- Ignores smaller creators in favor of follower count alone
- Partners with someone whose values visibly conflict with MVQUEEN's doctrine

---

## UGC From Creator Content

When a creator produces strong content:
1. Save it immediately (before it disappears)
2. Request usage rights if not already covered in the brief
3. Repurpose as: paid ad creative, website imagery, email content
4. Feature on MVQUEEN's own social channels with credit

Creator content that converts in organic feed almost always outperforms produced studio content in paid ads. This is one of MVQUEEN's most valuable content assets.

---

*07_Marketing / Influencer_Strategy.md*
*The right creator doesn't promote MVQUEEN. She lives it — and her audience feels the difference.*
