# 🧠 MVQUEEN — Conversion Psychology

---

## How MVQUEEN Women Make Purchase Decisions

MVQUEEN's customer is not an impulse buyer.
She is an identity-informed buyer — she purchases when a product feels aligned with who she is or who she is becoming, not when she's been pressured into it.

This changes everything about how MVQUEEN approaches conversion.

Pressure tactics work on impulse buyers.
Recognition and trust work on identity buyers.
MVQUEEN is built for the second type.

---

## The 5 Conversion Drivers

### DRIVER 01 — Emotional Recognition
**What it is:** She reads the copy or sees the content and thinks: *that is exactly me.*
**How MVQUEEN activates it:** Identity-specific copy, persona-aligned messaging, the Mirror Method in product descriptions.
**Conversion impact:** High — recognition creates instant trust.

### DRIVER 02 — Sensory Desire
**What it is:** She imagines the physical experience of using the product so vividly that she wants it.
**How MVQUEEN activates it:** Texture-first copy, sensory language in descriptions, close-up product imagery and video.
**Conversion impact:** High for beauty and body care categories specifically.

### DRIVER 03 — Social Proof
**What it is:** She sees evidence that women like her love this product.
**How MVQUEEN activates it:** Specific, story-rich reviews above the fold. UGC in product pages and ads. Real customer language in retargeting.
**Conversion impact:** Medium-high — especially for first-time buyers with hesitation.
**Quality over quantity:** One specific review ("My skin felt different by day 4") outperforms ten generic five-stars.

### DRIVER 04 — Permission
**What it is:** She wanted it but needed someone to remove the justification barrier.
**How MVQUEEN activates it:** Permission Grant copy framework, self-worth framing, removing the need for an occasion.
**Conversion impact:** Medium — particularly powerful for self-gifting purchases.

### DRIVER 05 — Ritual Fit
**What it is:** She can see exactly where this product lives in her daily ritual — it fits.
**How MVQUEEN activates it:** Ritual placement in copy, "add to your morning" framing, complementary product suggestions.
**Conversion impact:** Medium — improves AOV and reduces post-purchase doubt.

---

## Purchase Hesitation — What Stops Her

Understanding what stops her matters as much as understanding what moves her.

### Hesitation 01 — Quality Doubt
**She thinks:** "Is this actually as good as it looks?"
**MVQUEEN response:** Specific sensory details in copy (not vague claims), honest FAQ answers, authentic reviews with specifics, ingredients/materials listed transparently.

### Hesitation 02 — Price Justification
**She thinks:** "Can I justify spending this right now?"
**MVQUEEN response:** Never apologize for the price. Anchor the value in the emotional experience — what she gets, not what she pays. Bundle options that deliver better perceived value.

### Hesitation 03 — Fit Uncertainty
**She thinks:** "Will this work for my skin/hair/body type?"
**MVQUEEN response:** "Who this is for" section in every product description. Skin type and hair type guidance in FAQs. Honest limitations stated clearly — trust is built by saying "this may not be for you if..."

### Hesitation 04 — Timing
**She thinks:** "I'll come back to this later."
**MVQUEEN response:** Abandoned cart sequence. Retargeting. Back-in-stock notifications. Never manufactured urgency — but genuine scarcity communicated clearly.

### Hesitation 05 — Brand Trust (First Purchase)
**She thinks:** "I've never ordered from them before."
**MVQUEEN response:** Trust signals on product page (return policy, reviews, secure checkout badge), the brand story visible and accessible, social proof from real women.

---

## Conversion Architecture by Touchpoint

### Product Page
The single most important conversion surface.

**Above the fold must have:**
- Product name + short emotional description (2–3 sentences)
- Price — clearly visible, no games
- Variant selector (if applicable)
- At least 3 product images (product, lifestyle, in-use)
- Primary CTA button — "Add to Ritual" or equivalent
- At least 3 specific customer reviews

**Below the fold:**
- Long description following the 5-paragraph architecture
- Benefit bullets (5 — experience language, not features)
- FAQ section (4–6 questions, MVQUEEN voice)
- Cross-sell section ("Complete the ritual")
- Additional reviews

**What the product page never has:**
- Pop-ups that fire immediately on landing
- Fake scarcity counters
- Countdown timers on regular products
- Aggressive exit-intent popups with guilt language

---

### Checkout
The friction removal zone.

**MVQUEEN checkout priorities:**
- Guest checkout available — never force account creation to buy
- Progress indicator visible
- Trust badges at checkout (secure, returns policy)
- No surprise fees — shipping cost visible before checkout begins
- Upsell at checkout: one optional add-on, not a wall of offers

---

### Post-Click (Ad → Landing Page)
The emotional register of the ad must match the landing page exactly.

**If the ad is emotional and atmospheric → the landing page must be emotional and atmospheric.**
Not: the homepage with navigation and everything competing for her attention.
Ideal: the product page or a dedicated collection page that continues the story the ad started.

Message match is one of the most underrated conversion levers in ecommerce.

---

## Conversion Rate Benchmarks

| Surface | Industry avg | MVQUEEN target |
|---------|-------------|----------------|
| Overall store CVR | 1–2% | 3–4% |
| Product page CVR | 3–5% | 5–8% |
| Email to purchase | 2–4% | 5–7% |
| Retargeting ad CVR | 3–6% | 8–12% |
| Abandoned cart recovery | 5–10% | 10–15% |

MVQUEEN targets above-average conversion through emotional precision — not discount-driven incentives.

---

*07_Marketing / Conversion_Psychology.md*
*She doesn't need to be convinced. She needs to feel recognized. The purchase follows.*
