# 📊 MVQUEEN — Marketing Analytics

---

## Analytics Philosophy

Data in MVQUEEN is not collected to be reported.
It is collected to be acted on.

Every metric tracked has a decision attached to it.
If a metric doesn't inform a specific decision — it is not a priority metric.

MVQUEEN tracks what matters. Makes decisions from what it tracks.
The goal is not a beautiful dashboard. It is a better-performing brand.

---

## The Four Metric Categories

### 1. Revenue Metrics (Are we growing?)
### 2. Acquisition Metrics (Are we reaching the right women?)
### 3. Engagement Metrics (Are we keeping her attention?)
### 4. Retention Metrics (Is she coming back?)

Each category has daily, weekly, and monthly check-ins.

---

## Revenue Metrics

| Metric | Definition | Review Frequency |
|--------|-----------|-----------------|
| Total revenue | Gross sales for the period | Daily |
| Net revenue | After refunds and discounts | Weekly |
| Average order value (AOV) | Revenue ÷ orders | Weekly |
| Revenue per email | Email revenue ÷ emails sent | Per campaign |
| Revenue per SMS | SMS revenue ÷ messages sent | Per send |
| ROAS | Ad revenue ÷ ad spend | Weekly (if running ads) |
| Revenue by channel | Organic / Email / SMS / Paid / SEO | Monthly |
| Revenue by product | Which products drive the most | Monthly |
| Revenue by collection | Which collections perform | Monthly |

**AOV target:** $45+ (achieved through bundle strategy + cross-sell)
**Revenue growth target:** 15–20% month-over-month during growth phase

---

## Acquisition Metrics

| Metric | Definition | Review Frequency |
|--------|-----------|-----------------|
| Website sessions | Total visitors | Weekly |
| New vs returning visitors | % new | Weekly |
| Traffic by source | Organic / Social / Email / Paid / Direct | Weekly |
| Email opt-in rate | Subscribers ÷ visitors | Weekly |
| Cost per acquisition (CPA) | Ad spend ÷ new customers | Monthly |
| Customer acquisition cost (CAC) | Total marketing spend ÷ new customers | Monthly |
| Conversion rate (CVR) | Purchases ÷ sessions | Weekly |
| Product page CVR | Add-to-carts ÷ product page views | Weekly |

**CVR target:** 3–4% overall store
**Email opt-in rate target:** 3–5% of sessions
**CAC target:** Under $30 during growth phase (adjust as brand matures)

---

## Engagement Metrics

| Metric | Definition | Review Frequency |
|--------|-----------|-----------------|
| Email open rate | Opens ÷ delivered | Per campaign |
| Email click rate | Clicks ÷ delivered | Per campaign |
| Social reach | Accounts reached per post | Weekly |
| Social engagement rate | (Likes + comments + saves) ÷ reach | Weekly |
| Story completion rate | % who watch stories to the end | Weekly |
| TikTok video completion | % who watch to the end | Per video |
| Pinterest saves | Weekly saves | Weekly |
| Time on site | Average session duration | Weekly |
| Pages per session | Average pages viewed | Weekly |

**Email open rate target:** 35%+
**Social engagement rate target:** 4–6% (Instagram), 8–12% (TikTok)
**Time on site target:** 2:30+ minutes

---

## Retention Metrics

| Metric | Definition | Review Frequency |
|--------|-----------|-----------------|
| Repeat purchase rate | % who buy again within 90 days | Monthly |
| Customer lifetime value (LTV) | Average revenue per customer over time | Monthly |
| LTV:CAC ratio | Customer value vs acquisition cost | Monthly |
| Churn rate | % who haven't purchased in 90 days | Monthly |
| Loyalty program enrollment rate | % of customers enrolled | Monthly |
| Loyalty redemption rate | % of points redeemed | Monthly |
| Win-back rate | % of lapsed customers re-activated | Per campaign |

**Repeat purchase rate target:** 30%+ within 90 days of first purchase
**LTV:CAC target:** 3:1 minimum (meaning she generates 3x what she cost to acquire)

---

## Reporting Rhythm

### Daily (5 minutes)
- Revenue vs prior day
- Revenue vs same day last week
- Any anomalies (spike or drop)

### Weekly (30 minutes — every Monday)
- Revenue vs prior week
- Top performing products
- Email campaign performance
- Social top posts
- Ad ROAS if running
- Any channel underperforming — why?

### Monthly (2 hours — first Monday of month)
- Full revenue breakdown by channel and product
- Acquisition metrics vs targets
- Retention metrics — repeat purchase rate, LTV
- Email list health (growth, unsubscribes, engagement)
- Campaign performance review
- Next month priorities adjusted based on data

### Quarterly (Half day — end of quarter)
- Revenue vs quarterly goal
- Customer cohort analysis — how are different acquisition months performing?
- LTV trend — is it growing?
- Channel ROI — where is money best spent?
- Strategic decisions for next quarter

---

## The Decision Framework

Every metric triggers a specific decision when it falls below threshold:

| Metric Below Threshold | Immediate Action |
|----------------------|-----------------|
| CVR < 2% | Audit product pages — copy, imagery, reviews |
| Email open rate < 25% | Review subject lines, send time, list health |
| ROAS < 2x | Pause ads, audit creative before increasing spend |
| Repeat purchase rate < 20% | Strengthen post-purchase email sequence |
| AOV < $35 | Audit cross-sell placements and bundle pricing |
| Opt-in rate < 2% | Test new welcome offer or popup design |

Data without decisions is just noise. These thresholds create automatic triggers for action.

---

## Tools

| Tool | Purpose |
|------|---------|
| Shopify Analytics | Revenue, product, and order data |
| Google Analytics 4 | Traffic, sessions, behavior, attribution |
| Klaviyo | Email and SMS performance |
| Meta Ads Manager | Paid ad performance |
| Later / Planoly | Social scheduling and analytics |
| Pinterest Analytics | Pin performance, saves, traffic |
| TikTok Analytics | Video performance, audience data |

---

*07_Marketing / Analytics.md*
*Track what matters. Decide from what you track. Build from what you decide.*
